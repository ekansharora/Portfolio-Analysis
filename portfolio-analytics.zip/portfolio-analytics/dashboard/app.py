"""
app.py
Streamlit dashboard reading from the SQLite DB populated by pipeline.run.
Run: streamlit run dashboard/app.py
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

sys.path.append(str(Path(__file__).resolve().parents[1]))

from pipeline.storage import get_connection, load_metrics, load_prices  # noqa: E402

st.set_page_config(page_title="Portfolio Analytics", layout="wide")
st.title("Portfolio Analytics Dashboard")

conn = get_connection()
prices = load_prices(conn)

if prices.empty:
    st.warning(
        "No data yet. Run the pipeline first:\n\n"
        "`python -m pipeline.run --tickers AAPL,MSFT,SPY --start 2020-01-01 --benchmark SPY`"
    )
    st.stop()

all_tickers = sorted(prices["ticker"].unique())
selected = st.sidebar.multiselect("Tickers", all_tickers, default=all_tickers)
date_min, date_max = prices["date"].min(), prices["date"].max()
date_range = st.sidebar.date_input("Date range", (date_min, date_max))

filtered = prices[prices["ticker"].isin(selected)]
if isinstance(date_range, tuple) and len(date_range) == 2:
    start, end = date_range
    filtered = filtered[(filtered["date"] >= pd.Timestamp(start)) & (filtered["date"] <= pd.Timestamp(end))]

col1, col2 = st.columns([2, 1])

with col1:
    st.subheader("Price History")
    fig = px.line(filtered, x="date", y="close", color="ticker")
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("Cumulative Returns")
    pivot = filtered.pivot(index="date", columns="ticker", values="close")
    cum_returns = (pivot.pct_change().fillna(0) + 1).cumprod() - 1
    fig2 = px.line(cum_returns, labels={"value": "Cumulative Return", "date": "Date"})
    st.plotly_chart(fig2, use_container_width=True)

with col2:
    st.subheader("Latest Metrics")
    metrics = load_metrics(conn)
    if not metrics.empty:
        latest = metrics[metrics["ticker"].isin(selected)].sort_values("as_of", ascending=False)
        latest = latest.drop_duplicates("ticker")
        display_cols = ["ticker", "annualized_return", "annualized_volatility",
                         "sharpe_ratio", "sortino_ratio", "max_drawdown", "beta"]
        st.dataframe(
            latest[display_cols].set_index("ticker").style.format("{:.2%}", subset=[
                "annualized_return", "annualized_volatility", "max_drawdown"
            ]).format("{:.2f}", subset=["sharpe_ratio", "sortino_ratio", "beta"]),
            use_container_width=True,
        )
    else:
        st.info("No metrics computed yet — run the pipeline.")

st.subheader("Correlation Matrix")
returns_wide = pivot.pct_change().dropna()
if returns_wide.shape[1] > 1:
    corr = returns_wide.corr()
    fig3 = px.imshow(corr, text_auto=".2f", color_continuous_scale="RdBu_r", zmin=-1, zmax=1)
    st.plotly_chart(fig3, use_container_width=True)
else:
    st.info("Select at least two tickers to see correlations.")
