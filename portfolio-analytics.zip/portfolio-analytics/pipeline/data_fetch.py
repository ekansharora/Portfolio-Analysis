"""
data_fetch.py
Pulls daily OHLCV data for a list of tickers via yfinance and returns
tidy pandas DataFrames ready for storage.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date
from typing import Iterable

import pandas as pd
import yfinance as yf

logger = logging.getLogger(__name__)


@dataclass
class FetchConfig:
    tickers: list[str]
    start: str
    end: str | None = None  # defaults to today inside yfinance
    interval: str = "1d"


def fetch_prices(config: FetchConfig) -> pd.DataFrame:
    """
    Download adjusted close + volume for each ticker and return a single
    long-format DataFrame with columns: date, ticker, close, volume.
    """
    frames = []
    for ticker in config.tickers:
        logger.info("Fetching %s from %s to %s", ticker, config.start, config.end or date.today())
        raw = yf.download(
            ticker,
            start=config.start,
            end=config.end,
            interval=config.interval,
            auto_adjust=True,
            progress=False,
        )
        if raw.empty:
            logger.warning("No data returned for %s, skipping", ticker)
            continue

        df = raw[["Close", "Volume"]].reset_index()
        df.columns = ["date", "close", "volume"]
        df["ticker"] = ticker
        frames.append(df)

    if not frames:
        raise ValueError("No data fetched for any ticker — check tickers/date range")

    return pd.concat(frames, ignore_index=True).sort_values(["ticker", "date"])


def validate_tickers(tickers: Iterable[str]) -> list[str]:
    """Normalize/dedupe ticker input (e.g. 'aapl, msft' -> ['AAPL', 'MSFT'])."""
    cleaned = {t.strip().upper() for t in tickers if t.strip()}
    if not cleaned:
        raise ValueError("At least one ticker is required")
    return sorted(cleaned)
