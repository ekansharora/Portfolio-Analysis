"""
storage.py
Thin SQLite persistence layer. Keeps the dashboard decoupled from the
fetch/compute pipeline — the dashboard only ever reads from this DB.
"""
from __future__ import annotations

import sqlite3
from pathlib import Path

import pandas as pd

DEFAULT_DB_PATH = Path("data/portfolio.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS prices (
    date TEXT NOT NULL,
    ticker TEXT NOT NULL,
    close REAL NOT NULL,
    volume INTEGER,
    PRIMARY KEY (date, ticker)
);

CREATE TABLE IF NOT EXISTS metrics (
    ticker TEXT NOT NULL,
    as_of TEXT NOT NULL,
    annualized_return REAL,
    annualized_volatility REAL,
    sharpe_ratio REAL,
    sortino_ratio REAL,
    max_drawdown REAL,
    beta REAL,
    PRIMARY KEY (ticker, as_of)
);
"""


def get_connection(db_path: Path = DEFAULT_DB_PATH) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.executescript(SCHEMA)
    return conn


def upsert_prices(conn: sqlite3.Connection, df: pd.DataFrame) -> int:
    """Insert-or-replace price rows. Returns row count written."""
    records = df.copy()
    records["date"] = records["date"].astype(str)
    rows = records[["date", "ticker", "close", "volume"]].values.tolist()
    conn.executemany(
        "INSERT OR REPLACE INTO prices (date, ticker, close, volume) VALUES (?, ?, ?, ?)",
        rows,
    )
    conn.commit()
    return len(rows)


def upsert_metrics(conn: sqlite3.Connection, df: pd.DataFrame) -> int:
    records = df.copy()
    records["as_of"] = records["as_of"].astype(str)
    cols = ["ticker", "as_of", "annualized_return", "annualized_volatility",
            "sharpe_ratio", "sortino_ratio", "max_drawdown", "beta"]
    rows = records[cols].values.tolist()
    conn.executemany(
        f"INSERT OR REPLACE INTO metrics ({', '.join(cols)}) "
        f"VALUES ({', '.join(['?'] * len(cols))})",
        rows,
    )
    conn.commit()
    return len(rows)


def load_prices(conn: sqlite3.Connection, tickers: list[str] | None = None) -> pd.DataFrame:
    query = "SELECT date, ticker, close, volume FROM prices"
    params: tuple = ()
    if tickers:
        placeholders = ", ".join(["?"] * len(tickers))
        query += f" WHERE ticker IN ({placeholders})"
        params = tuple(tickers)
    df = pd.read_sql_query(query, conn, params=params, parse_dates=["date"])
    return df.sort_values(["ticker", "date"])


def load_metrics(conn: sqlite3.Connection) -> pd.DataFrame:
    return pd.read_sql_query("SELECT * FROM metrics ORDER BY as_of DESC", conn)
