"""
metrics.py
Pure functions for portfolio/asset analytics. Kept dependency-free of
storage/fetch so they're trivially unit-testable.

All return series are expected to be simple daily returns (pct_change),
not log returns, unless stated otherwise.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

TRADING_DAYS_PER_YEAR = 252


def daily_returns(prices: pd.Series) -> pd.Series:
    return prices.pct_change().dropna()


def annualized_return(returns: pd.Series) -> float:
    if returns.empty:
        return np.nan
    compounded = (1 + returns).prod()
    n_years = len(returns) / TRADING_DAYS_PER_YEAR
    if n_years == 0:
        return np.nan
    return compounded ** (1 / n_years) - 1


def annualized_volatility(returns: pd.Series) -> float:
    if returns.empty:
        return np.nan
    return returns.std(ddof=1) * np.sqrt(TRADING_DAYS_PER_YEAR)


def sharpe_ratio(returns: pd.Series, risk_free_rate: float = 0.0) -> float:
    vol = annualized_volatility(returns)
    if not vol or np.isnan(vol) or vol == 0:
        return np.nan
    excess = annualized_return(returns) - risk_free_rate
    return excess / vol


def sortino_ratio(returns: pd.Series, risk_free_rate: float = 0.0) -> float:
    downside = returns[returns < 0]
    if downside.empty:
        return np.nan
    downside_dev = downside.std(ddof=1) * np.sqrt(TRADING_DAYS_PER_YEAR)
    if downside_dev == 0:
        return np.nan
    excess = annualized_return(returns) - risk_free_rate
    return excess / downside_dev


def max_drawdown(prices: pd.Series) -> float:
    if prices.empty:
        return np.nan
    cumulative_max = prices.cummax()
    drawdown = (prices - cumulative_max) / cumulative_max
    return drawdown.min()


def beta(asset_returns: pd.Series, benchmark_returns: pd.Series) -> float:
    asset = asset_returns.rename("__asset__")
    benchmark = benchmark_returns.rename("__benchmark__")
    aligned = pd.concat([asset, benchmark], axis=1, join="inner").dropna()
    if aligned.shape[0] < 2:
        return np.nan
    covariance = aligned["__asset__"].cov(aligned["__benchmark__"])
    benchmark_var = aligned["__benchmark__"].var()
    if benchmark_var == 0:
        return np.nan
    return covariance / benchmark_var


def correlation_matrix(returns_by_ticker: pd.DataFrame) -> pd.DataFrame:
    return returns_by_ticker.corr()


def compute_all_metrics(
    prices_wide: pd.DataFrame,
    benchmark_ticker: str | None = None,
    risk_free_rate: float = 0.0,
) -> pd.DataFrame:
    """
    prices_wide: DataFrame indexed by date, one column per ticker (close price).
    Returns one row per ticker with all metrics.
    """
    returns_wide = prices_wide.pct_change().dropna(how="all")
    benchmark_returns = returns_wide[benchmark_ticker] if benchmark_ticker in returns_wide else None

    rows = []
    for ticker in prices_wide.columns:
        r = returns_wide[ticker].dropna()
        p = prices_wide[ticker].dropna()
        row = {
            "ticker": ticker,
            "annualized_return": annualized_return(r),
            "annualized_volatility": annualized_volatility(r),
            "sharpe_ratio": sharpe_ratio(r, risk_free_rate),
            "sortino_ratio": sortino_ratio(r, risk_free_rate),
            "max_drawdown": max_drawdown(p),
            "beta": beta(r, benchmark_returns) if benchmark_returns is not None and ticker != benchmark_ticker else np.nan,
        }
        rows.append(row)

    return pd.DataFrame(rows)
