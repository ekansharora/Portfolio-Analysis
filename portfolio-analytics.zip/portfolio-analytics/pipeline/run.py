"""
run.py
CLI entrypoint: fetch -> store -> compute metrics -> store metrics.

Usage:
    python -m pipeline.run --tickers AAPL,MSFT,SPY --start 2020-01-01 --benchmark SPY
"""
from __future__ import annotations

import argparse
import logging
from datetime import date

import pandas as pd

from pipeline.data_fetch import FetchConfig, fetch_prices, validate_tickers
from pipeline.metrics import compute_all_metrics
from pipeline.storage import get_connection, load_prices, upsert_metrics, upsert_prices

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Fetch market data and compute portfolio analytics.")
    parser.add_argument("--tickers", required=True, help="Comma-separated tickers, e.g. AAPL,MSFT,SPY")
    parser.add_argument("--start", required=True, help="Start date YYYY-MM-DD")
    parser.add_argument("--end", default=None, help="End date YYYY-MM-DD (default: today)")
    parser.add_argument("--benchmark", default=None, help="Ticker to use as benchmark for beta calc")
    parser.add_argument("--risk-free-rate", type=float, default=0.0)
    parser.add_argument("--db-path", default="data/portfolio.db")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    tickers = validate_tickers(args.tickers.split(","))
    if args.benchmark:
        benchmark = args.benchmark.strip().upper()
        if benchmark not in tickers:
            tickers.append(benchmark)
    else:
        benchmark = None

    config = FetchConfig(tickers=tickers, start=args.start, end=args.end)
    prices_long = fetch_prices(config)

    conn = get_connection(db_path=__import__("pathlib").Path(args.db_path))
    n_written = upsert_prices(conn, prices_long)
    logger.info("Wrote %d price rows to %s", n_written, args.db_path)

    prices_wide = load_prices(conn, tickers).pivot(index="date", columns="ticker", values="close")
    metrics_df = compute_all_metrics(prices_wide, benchmark_ticker=benchmark, risk_free_rate=args.risk_free_rate)
    metrics_df["as_of"] = pd.Timestamp(date.today())

    n_metrics = upsert_metrics(conn, metrics_df)
    logger.info("Wrote %d metric rows", n_metrics)

    print(metrics_df.to_string(index=False))


if __name__ == "__main__":
    main()
