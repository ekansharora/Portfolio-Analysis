import numpy as np
import pandas as pd

from pipeline.metrics import (
    annualized_return,
    annualized_volatility,
    beta,
    compute_all_metrics,
    daily_returns,
    max_drawdown,
    sharpe_ratio,
    sortino_ratio,
)


def test_daily_returns_basic():
    prices = pd.Series([100, 110, 121])
    returns = daily_returns(prices)
    assert len(returns) == 2
    assert np.isclose(returns.iloc[0], 0.10)
    assert np.isclose(returns.iloc[1], 0.10)


def test_annualized_return_positive_drift(synthetic_prices):
    r = daily_returns(synthetic_prices["AAA"])
    ann_ret = annualized_return(r)
    # AAA was simulated with 15% drift over 2 years; allow noise tolerance
    assert 0.0 < ann_ret < 0.40


def test_annualized_volatility_matches_scale(synthetic_prices):
    r = daily_returns(synthetic_prices["BBB"])
    vol = annualized_volatility(r)
    assert 0.05 < vol < 0.35


def test_max_drawdown_is_non_positive(synthetic_prices):
    dd = max_drawdown(synthetic_prices["AAA"])
    assert dd <= 0


def test_max_drawdown_flat_series_is_zero(flat_prices):
    assert max_drawdown(flat_prices) == 0


def test_sharpe_ratio_zero_vol_returns_nan(flat_prices):
    r = daily_returns(flat_prices)
    assert np.isnan(sharpe_ratio(r))


def test_sortino_no_downside_returns_nan():
    # Strictly increasing returns -> no downside deviation
    r = pd.Series([0.01] * 50)
    assert np.isnan(sortino_ratio(r))


def test_beta_of_benchmark_with_itself_is_one(synthetic_prices):
    r = daily_returns(synthetic_prices["BENCH"])
    b = beta(r, r)
    assert np.isclose(b, 1.0)


def test_beta_insufficient_overlap_returns_nan():
    a = pd.Series([0.01, 0.02], index=pd.date_range("2022-01-01", periods=2))
    b_series = pd.Series([0.01], index=pd.date_range("2022-01-01", periods=1))
    assert np.isnan(beta(a, b_series))


def test_compute_all_metrics_shape(synthetic_prices):
    result = compute_all_metrics(synthetic_prices, benchmark_ticker="BENCH")
    assert set(result["ticker"]) == {"AAA", "BBB", "BENCH"}
    expected_cols = {
        "ticker", "annualized_return", "annualized_volatility",
        "sharpe_ratio", "sortino_ratio", "max_drawdown", "beta",
    }
    assert expected_cols.issubset(result.columns)
    # Benchmark's own beta column should be NaN (we skip self-beta)
    bench_row = result[result["ticker"] == "BENCH"].iloc[0]
    assert np.isnan(bench_row["beta"])


def test_compute_all_metrics_beta_is_reasonable(synthetic_prices):
    result = compute_all_metrics(synthetic_prices, benchmark_ticker="BENCH")
    aaa_beta = result.loc[result["ticker"] == "AAA", "beta"].iloc[0]
    # Independently generated series -> beta should be small, not wildly large
    assert -2.0 < aaa_beta < 2.0
