import numpy as np
import pandas as pd
import pytest


@pytest.fixture
def synthetic_prices() -> pd.DataFrame:
    """
    Deterministic synthetic price series for two tickers + a benchmark,
    so tests never depend on network access or real market data.
    """
    rng = np.random.default_rng(seed=42)
    n_days = 252 * 2  # 2 years
    dates = pd.date_range("2022-01-03", periods=n_days, freq="B")

    def make_series(start_price: float, drift: float, vol: float) -> np.ndarray:
        daily_returns = rng.normal(loc=drift / 252, scale=vol / np.sqrt(252), size=n_days)
        return start_price * (1 + daily_returns).cumprod()

    data = {
        "AAA": make_series(100, drift=0.15, vol=0.25),
        "BBB": make_series(50, drift=0.05, vol=0.15),
        "BENCH": make_series(200, drift=0.08, vol=0.18),
    }
    return pd.DataFrame(data, index=dates)


@pytest.fixture
def flat_prices() -> pd.Series:
    """A price series with zero volatility, for edge-case testing."""
    dates = pd.date_range("2022-01-03", periods=100, freq="B")
    return pd.Series([100.0] * 100, index=dates)
